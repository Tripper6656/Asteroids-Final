// index.js
import Game from './game';
import './main';
import Asteroid from './asteroid';
import Laser from './laser';
import './game.css';
